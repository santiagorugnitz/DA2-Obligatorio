﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public class ReportItem
    {
        public accommodation accommodation {get; set;}
        public int ReservationsQuantity { get; set; }
    }
}
